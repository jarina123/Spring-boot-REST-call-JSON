package Springboot.model;

//model class for student table in database....
public class student {
	
	private String name;
	private String classth;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClassth() {
		return classth;
	}
	public void setClassth(String classth) {
		this.classth = classth;
	}
	
	

}
