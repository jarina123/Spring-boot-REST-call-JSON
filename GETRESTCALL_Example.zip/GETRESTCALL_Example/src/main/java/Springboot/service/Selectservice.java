package Springboot.service;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
@Component
@Service
public class Selectservice {

	
	public List<Map<String, Object>> selectcolumns(NamedParameterJdbcTemplate jdbcTemplate,Map<String,Object> mp,final List<Map<String,Object>> list) {
		
		 String sql = "select * FROM student where name = :name";
		 
		 
		 jdbcTemplate.query(sql,mp,new ResultSetExtractor <List<Map<String,Object>>>()
		 {
			 
			 public List<Map<String,Object>> extractData(ResultSet rs)throws SQLException 
			 {
				
				 while(rs.next())
				 {
					 Map<String,Object> temp=new HashMap<String,Object>();
					 temp.put("name", rs.getString(1));
					 temp.put("classth", rs.getString(2));
					 
					 list.add(temp);
				 }
				 return list;
			 }
			 
		 });
		 
		 return list;
		 
		 }
	
	
	
	
	
	
	
	//REST call without where clause...
	
	public List<Map<String, Object>> selectcolumns1(NamedParameterJdbcTemplate jdbcTemplate,final List<Map<String,Object>> list) {
		
		 String sql = "select * FROM student ";
		 
		 
		 jdbcTemplate.query(sql,new ResultSetExtractor <List<Map<String,Object>>>()
		 {
			 
			 public List<Map<String,Object>> extractData(ResultSet rs)throws SQLException 
			 {
				
				 while(rs.next())
				 {
					 Map<String,Object> temp=new HashMap<String,Object>();
					 temp.put("name", rs.getString(1));
					 temp.put("classth", rs.getString(2));
					 
					 list.add(temp);
				 }
				 return list;
			 }
			 
		 });
		 
		 return list;
		 
		 }
	
	
	
	//REST call to insert data into Student table in database
	
	public static void insertUser(NamedParameterJdbcTemplate jdbcTemplate, Map<String, Object> arguments) {
		String query = "insert into student values(:name,:classth)";
		
		jdbcTemplate.update(query, arguments);
		System.out.println("data inserted in user table");

		
	}





// Detele REST call ...............

	public String deletedata1(NamedParameterJdbcTemplate jdbcTemplate, Map<String, Object> argMap) {
		
		 String sql = "delete FROM student where name = :name";
		 
		 jdbcTemplate.update(sql, argMap);
		return "data deleted";
	}





//update REST call...........

	public String updatedata1(NamedParameterJdbcTemplate jdbcTemplate, Map<String, Object> argMap) {
		
		String sql = "update student set name='jarina' where name = :name";
		jdbcTemplate.update(sql, argMap);
		return "data updated";
	}
	
	
	
	
}
