package getRESTcall.Spirngboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;



import Springboot.model.student;
import Springboot.service.Selectservice;

import java.util.*;

import javax.servlet.http.HttpServletRequest;

@RestController
public class HelloWorldController {
	

	@Autowired
	private Selectservice ssc;
	
	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate = null;

	public void setDataSource(javax.sql.DataSource datasource) {
		this.jdbcTemplate = new NamedParameterJdbcTemplate(datasource);
	}


	
	@RequestMapping(method=RequestMethod.GET, path="/hello-world")  
	public String helloWorld()  
	{  
	return "Hello jarina";  
	}  
	
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/selectdata")
	@ResponseBody
	public List<Map<String, Object>> getAllUsers(HttpServletRequest request,
			@RequestParam(value = "name", defaultValue = "") String tn) {

		{
			
			
			System.out.println("inside getalluser");
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("name", tn);
			System.out.println("inside REST call.....");
			System.out.println("argmap is: "+ argMap);

			List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
			ssc.selectcolumns(jdbcTemplate, argMap, list);
			return list;

		}

	}
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/selectdatawithoutwhereclause")
	@ResponseBody
	public List<Map<String, Object>> getAllUsers1(HttpServletRequest request) {

		
			
			
			System.out.println("inside getalluser1");
			/*
			 * Map<String, Object> argMap = new HashMap<String, Object>();
			 * argMap.put("name", tn); System.out.println("inside REST call.....");
			 * System.out.println("argmap is: "+ argMap);
			 */

			List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
			ssc.selectcolumns1(jdbcTemplate, list);
			return list;



	}
	
	
	
	//insert data into student table .....write POST REST CALL
	
	@RequestMapping(value = "/insertuser", method = RequestMethod.POST)
	@ResponseBody
	public String insertUser(@RequestBody student std) {
		String name = std.getName();
		String classth = std.getClassth();
		System.out.println("inside POST rest call");

		Map<String, Object> arguments = new HashMap<String, Object>();
		arguments.put("name", name);
		arguments.put("classth", classth);
		

		ssc.insertUser(jdbcTemplate, arguments);
		System.out.println("user inserted successfully");

		return "User Inserted Sussessfully";

	}
	
	
	//using only jdbctemplate 
	 @Autowired  
	    JdbcTemplate jdbc;   
	
	@RequestMapping("/insert")  
    public String index(){  
        jdbc.execute("insert into student(name,classth)values('pkr','16th')");  
        return"data inserted Successfully";  
    }  
	
	
    // delete REST call by using simple JdbcTemplate
	@RequestMapping("/delete")  
    public String indexdelete(){  
        jdbc.update("delete from student where name='bbb'");  
        System.out.println("data deleted Successfully");
        return"data deleted Successfully";  
    }  
	
	
	
	//delete REST call .....
	@RequestMapping(method = RequestMethod.DELETE, value = "/deletedata")
	@ResponseBody
	public String deleteUsers(HttpServletRequest request,
			@RequestParam(value = "name", defaultValue = "") String tn) {

		{
			
			
			System.out.println("inside getalluser");
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("name", tn);
			System.out.println("inside REST call.....");
			System.out.println("argmap is: "+ argMap);

			List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
			ssc.deletedata1(jdbcTemplate,argMap);
			/* ssc.selectcolumns(jdbcTemplate, argMap, list); */
			return "data deleted successfully";

		}

	}
	
	
	
	
	
	
	//PUT REST call .....
		@RequestMapping(method = RequestMethod.PUT, value = "/updatedata")
		@ResponseBody
		public String updateUsers(HttpServletRequest request,
				@RequestParam(value = "name", defaultValue = "") String tn) {

			{
				
				
				System.out.println("inside getalluser");
				Map<String, Object> argMap = new HashMap<String, Object>();
				argMap.put("name", tn);
				System.out.println("inside REST call.....");
				System.out.println("argmap is: "+ argMap);

				List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
				ssc.updatedata1(jdbcTemplate,argMap);
				/* ssc.selectcolumns(jdbcTemplate, argMap, list); */
				return "data updated successfully";

			}

		}
	
	
	
	
}
